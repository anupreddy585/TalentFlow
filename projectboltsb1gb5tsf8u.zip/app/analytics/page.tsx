"use client"

import { AnalyticsPage } from "../../src/pages/AnalyticsPage"
import { AppLayout } from "../../components/layout/AppLayout"

export default function Analytics() {
  return (
    <AppLayout>
      <AnalyticsPage />
    </AppLayout>
  )
}
