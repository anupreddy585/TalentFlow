"use client"

import { AssessmentBuilderPage } from "../../../src/pages/AssessmentBuilderPage"
import { AppLayout } from "../../../components/layout/AppLayout"

export default function AssessmentBuilder() {
  return (
    <AppLayout>
      <AssessmentBuilderPage />
    </AppLayout>
  )
}
