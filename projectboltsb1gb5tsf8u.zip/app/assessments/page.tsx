"use client"

import { AssessmentsPage } from "../../src/pages/AssessmentsPage"
import { AppLayout } from "../../components/layout/AppLayout"

export default function Assessments() {
  return (
    <AppLayout>
      <AssessmentsPage />
    </AppLayout>
  )
}
