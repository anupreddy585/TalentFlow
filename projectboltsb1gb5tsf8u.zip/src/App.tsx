import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { setupWorker } from 'msw';
import { handlers } from './lib/msw-handlers';
import { seedDatabase, isDatabaseEmpty } from './lib/seed-data';
import { Layout } from './components/layout/Layout';
import { JobsPage } from './pages/JobsPage';
import { JobDetailPage } from './pages/JobDetailPage';
import { CandidatesPage } from './pages/CandidatesPage';
import { AssessmentsPage } from './pages/AssessmentsPage';
import { AssessmentBuilderPage } from './pages/AssessmentBuilderPage';
import { AnalyticsPage } from './pages/AnalyticsPage';

// Setup MSW
const worker = setupWorker(...handlers);

function App() {
  useEffect(() => {
    const initializeApp = async () => {
      // Start MSW
      await worker.start({ 
        onUnhandledRequest: 'bypass',
        serviceWorker: {
          url: '/mockServiceWorker.js'
        }
      });

      // Check if database needs seeding
      const isEmpty = await isDatabaseEmpty();
      if (isEmpty) {
        await seedDatabase();
      }
    };

    initializeApp();
  }, []);

  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/jobs" replace />} />
            <Route path="jobs" element={<JobsPage />} />
            <Route path="jobs/:id" element={<JobDetailPage />} />
            <Route path="candidates" element={<CandidatesPage />} />
            <Route path="assessments" element={<AssessmentsPage />} />
            <Route path="assessments/:jobId" element={<AssessmentBuilderPage />} />
            <Route path="analytics" element={<AnalyticsPage />} />
          </Route>
        </Routes>
        
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
      </div>
    </BrowserRouter>
  );
}

export default App;
