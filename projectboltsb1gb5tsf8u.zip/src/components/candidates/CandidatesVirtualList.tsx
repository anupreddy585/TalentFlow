import React, { useState, useEffect } from 'react';
import { FixedSizeList } from 'react-window';
import { Candidate } from '../../types';
import { CandidateCard } from './CandidateCard';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { useCandidatesStore } from '../../store/candidates-store';

interface CandidatesVirtualListProps {
  candidates: Candidate[];
  loading: boolean;
  onCandidateClick: (candidate: Candidate) => void;
}

interface ItemProps {
  index: number;
  style: React.CSSProperties;
}

export function CandidatesVirtualList({ candidates, loading, onCandidateClick }: CandidatesVirtualListProps) {
  const { selectCandidate } = useCandidatesStore();

  const Item = ({ index, style }: ItemProps) => {
    const candidate = candidates[index];
    
    if (!candidate) {
      return (
        <div style={style} className="p-4">
          <div className="animate-pulse bg-gray-200 h-24 rounded-lg" />
        </div>
      );
    }

    return (
      <div style={style} className="p-2">
        <CandidateCard
          candidate={candidate}
          onView={selectCandidate}
          onClick={onCandidateClick}
        />
      </div>
    );
  };

  if (loading && candidates.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (candidates.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No candidates found</p>
        <p className="text-gray-400 text-sm mt-2">
          Try adjusting your search or filter criteria
        </p>
      </div>
    );
  }

  return (
    <div className="h-full">
      <FixedSizeList
        height={600}
        itemCount={candidates.length}
        itemSize={120}
        className="scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100"
      >
        {Item}
      </FixedSizeList>
    </div>
  );
}
